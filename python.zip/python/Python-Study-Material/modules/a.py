def greetings(name):
    print("Hellow" + name)


person = {
    "name": "Amit",
    "age": 26,
    "Country": "India"

}

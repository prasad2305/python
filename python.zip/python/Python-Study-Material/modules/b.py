student = {
    "name": "Amit",
    "age": 26,
    "Country": "India"

}

# # # File Handling Mean create,append,read,write the file
# # # "r" -> Read
# # # "x" -> create
# # # "a" -> append
# # # "w" -> write

# # # create a file
# # import os
# # f = open("myfile.txt", "x")

# # write a file
# # fs = open("mydata.txt", 'a')


# # def append_data(f):
# #     f.write("Now the file has more contentssssssssssssssssss!")
# #     f.close()


# # append_data(fs)

# # # read data of the file
# # fs = open("mydata.txt", 'r')


# # def read_data(f):
# #     print(f.read())


# # read_data(fs)

# # fs = open("mydata.txt", 'w')


# # def write_data(f):
# #     f.write("Now the file has more asdasd!")
# #     f.close()


# # write_data(fs)


# # # Delete file
# # import os
# # f.close()
# # os.remove("myfile.txt")

# # # check if file exists
# # if os.path.exists("myfils.txt"):
# #     os.remove("myfils.txt")
# # else:
# #     print("file not found")

# import os
# os.rename("mydata.txt", 'yourdata.txt')
